# fluxoDeCaixa
Fluxo de caixa semanal, desenvolvido em HTML5 e Js 6 
